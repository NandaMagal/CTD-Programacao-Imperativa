# CTD-T05-PROGIMP
## Repositório para Aulas TURMA 05 - Programação Imperativa [0821]

### Recomendação de PLUGINS para VS-CODE
Name:**Code Runner**
  Id: formulahendry.code-runner
  Description: Run C, C++, Java, JS, PHP, Python, Perl, Ruby, Go, Lua, Groovy, PowerShell, CMD, BASH, F#, C#, VBScript, TypeScript, CoffeeScript, Scala, Swift, Julia, Crystal, OCaml, R, AppleScript, Elixir, VB.NET, Clojure, Haxe, Obj-C, Rust, Racket, Scheme, AutoHotkey, AutoIt, Kotlin, Dart, Pascal, Haskell, Nim, 
  Version: 0.11.6
  Publisher: Jun Han
  
  **VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=formulahendry.code-runner**

Name: **SonarLint**
  Id: sonarsource.sonarlint-vscode
  Description: SonarLint is an IDE extension that helps you detect and fix quality issues as you write code in JavaScript, TypeScript, Python, Java, HTML and PHP.
  Version: 3.0.0
  Publisher: SonarSource
  
  **VS Marketplace Link: https://marketplace.visualstudio.com/items?itemName=SonarSource.sonarlint-vscode**
