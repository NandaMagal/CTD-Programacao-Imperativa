
let nome = "Danilo";
let idade = 25;
let usuarioAtivo = true;
let teste = 0.1;
 
console.log(nome);
console.log(idade);
console.log(usuarioAtivo);
console.log("teste mensagem")
console.log(teste);
